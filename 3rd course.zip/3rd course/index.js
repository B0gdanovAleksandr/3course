const express = require('express');
const http = require('http');
const morgan = require('morgan');
const bodyParser = require('body-parser');
const dishRoutes = require('./routes/dishRouter'); 
const promoRoutes = require('./routes/promoRouter'); 
const leaderRoutes = require('./routes/leaderRouter'); 

const hostname = 'localhost';
const port = 3000;

const app = express();

app.use(morgan('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
express.static(__dirname + '/public')

app.use('/dishes',dishRoutes);
app.use('/promotions',promoRoutes);
app.use('/leaders',leaderRoutes);

app.use((req,res,next)=>{
    res.setHeader('Content-Type', 'text/html');
    res.statusCode = 200;
    res.end(`<html><body><h1 style="text-align:center;">Invalid Request "http://${hostname}:${port}${req.url}" for the server!<br>Valid url's <br>"http://${hostname}:${port}/dishes"<br>"http://${hostname}:${port}/leader"<br>"http://${hostname}:${port}/promo"</h1></body></html>`);
})

const server = http.createServer(app);

server.listen(port, hostname, ()=>{
    console.log(`Server running at http://${hostname}:${port}`);
})