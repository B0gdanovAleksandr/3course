const express = require('express');
const bodyParser = require('body-parser');
const promoRouter = express.Router();
promoRouter.use(bodyParser.json());


promoRouter.route('/').all((req,res,next)=>{
    res.statusCode = 200;
    res.setHeader('Content-Type', 'text/html');
    next();
}).get((req,res)=>{
    res.end(`<html><body><h1 style='text-align:center;'>Will send all the promo to you!</h1></body></html>`);
}).post((req,res,next)=>{
    res.end(`<html><body><h1 style='text-align:center'>Will add your promo : ${req.body.name} with details ${req.body.description} to the menu</h1></body></html>`);
}).put((req,res,next)=>{
    res.end(`<html><body><h1 style='text-align:center'>Will update your promo : ${req.body.name} with details ${req.body.description} to the menu</h1></body></html>`);
}).delete((req,res,next)=>{
    res.statusCode = 403;
    res.end(`<html><body><h1 style='text-align:center'>Delete operation not allowed!</h1></body></html>`);
});

promoRouter.route('/:promoid').all((req,res,next)=>{
    res.statusCode = 200;
    res.setHeader('Content-Type', 'text/html');
    next();
}).get((req,res)=>{
    res.end(`<html><body><h1 style='text-align:center'>Will send the promo with id : ${req.params.promoid} to you!</h1></body></html>`);
}).post((req,res,next)=>{
    res.statusCode = 403;
    res.end(`<html><body><h1 style='text-align:center'>Post operation not allowed for the request Id : ${req.params.promoid}</h1></body></html>`);
}).put((req,res,next)=>{
    console.log(req.body);
    res.end(`<html><body><h1 style='text-align:center'>Will update your promo : ${req.body.name} with details ${req.body.description} to the menu</h1></body></html>`);
}).delete((req,res,next)=>{
    res.end(`<html><body><h1 style='text-align:center'>Deleting promo with Id : ${req.params.promoid}</h1></body></html>`);
});

module.exports = promoRouter;