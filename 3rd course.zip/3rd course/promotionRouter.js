const express = require('express');
const bodyParser = require('body-parser');
const Promotions =require('../models/promotions');
const promotionRouter = express.Router();
promotionRouter.use(bodyParser.json());
//for handling / route.
promotionRouter.route('/')
    .get((req,res,next)=>{
        Promotions.find({})
        .then((Promotions)=>{
            res.stausCode =200;
            res.setHeader('Content-Type','application/json');
            res.json(Promotions);
        },(err)=>{next(err)})
     })
     .post((req,res,next)=>{
         Promotions.create(req.body)
         .then((Promotion)=>{
             console.log('Promotion Created',Promotion);
             res.statusCode =200;
             res.setHeader('Content-Type','application/json');
             res.json(Promotion);
         },(err)=>{next(err)})
         .catch((err) => next(err));
     })
     .put((req,res,next)=>{
         res.statusCode =403;
         res.end('Put operation not supported');
     })
     .delete((req,res,next)=>{
        Promotions.remove({})
        .then((resp)=>{
            res.statusCode =200;
            res.setHeader('Content-Type','application/json');
            res.json(resp);
        },(err)=>next(err))
        .catch((err)=>next(err));
     });
 //for handling /promoId route
 promotionRouter.route('/:promoId')
     .get((req,res,next)=>{
          Promotions.findById(req.params.promoId)
      .then((Promotion)=>{
     
         res.statusCode =200;
         res.setHeader('Content-Type','application/json');
         res.json(Promotion);
     },(err)=>{next(err)})
     .catch((err) => next(err));
 })
     .post((req,res,next)=>{
          res.end('Post operation not supported');
      })
      .put((req,res,next)=>{
         Promotions.findByIdAndUpdate(req.params.promoId,{
             $set:req.body
         },{new:true})
         .then((Promotion)=>{
     
             res.statusCode =200;
             res.setHeader('Content-Type','application/json');
             res.json(Promotion);
         },(err)=>{next(err)})
         .catch((err) => next(err));
         
      })
     .delete((req,res,next)=>{
        Promotions.findByIdAndRemove(req.params.promoId)
        .then((resp)=>{
         res.statusCode =200;
         res.setHeader('Content-Type','application/json');
         res.json(resp);
     },(err)=>next(err))
     .catch((err)=>next(err));
     });

module.exports=promotionRouter;